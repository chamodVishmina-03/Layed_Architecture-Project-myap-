package lk.ijse.dep.service;

// Human player
public class HumanPlayer extends Player {

    public HumanPlayer(Board board) {
        super(board);   // Call Player constructor
    }

    @Override
    public void movePiece(int col) {

        // If the selected column is full then become stop
        if (!board.isLegalMove(col)) {
            return;
        }

        // Put the BLUE piece into the column
        board.updateMove(col, Piece.BLUE);

        // inform the UI that human played in that column
        board.getBoardUI().update(col, true);

        // Check human wins
        Winner winner = board.findWinner();
        if (winner.getWinningPiece() != Piece.EMPTY) {
            board.getBoardUI().notifyWinner(winner); // Show winner
            return;
        }

        // If no empty moves left, it shows tie
        if (!board.existLegalMoves()) {
            board.getBoardUI().notifyWinner(new Winner(Piece.EMPTY));
        }
    }
}
