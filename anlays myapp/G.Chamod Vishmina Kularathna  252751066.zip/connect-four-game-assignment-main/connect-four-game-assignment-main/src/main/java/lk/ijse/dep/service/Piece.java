package lk.ijse.dep.service;

public enum Piece {
BLUE,GREEN,EMPTY

    // BLUE --> A blue player's piece
    // GREEN --> A green player's piece
    // EMPTY --> no piece yet


}
