package lk.ijse.dep.service;

public class BoardImpl implements Board {

    // 2D array to store pieces (BLUE, GREEN, EMPTY)
    private Piece[][] pieces;

    // To update the UI
    private BoardUI boardui;

    // Return the board array
    public Piece[][] getPieces() {
        return pieces;
    }

    // Constructor
    public BoardImpl(BoardUI boardui) {
        this.boardui = boardui;

        // Create the board with given size
        pieces = new Piece[NUM_OF_COLUMNS][NUM_OF_ROWS];


        for (int i = 0; i < NUM_OF_COLUMNS; i++) {  // Set all slots as EMPTY at the start
            for (int j = 0; j < NUM_OF_ROWS; j++) {
                pieces[i][j] = Piece.EMPTY;
            }
        }
    }
    @Override
    public BoardUI getBoardUI() {    // Return UI object
        return boardui;
    }

    // Find next empty row in column
    @Override
    public int findNextAvailableSpot(int col) {
        for (int i = 0; i < NUM_OF_ROWS; i++) {
            if (pieces[col][i] == Piece.EMPTY) {
                return i; // return first empty row
            }
        }
        return -1;
    }

    // Check   player can drop a piece in  column
    @Override
    public boolean isLegalMove(int col) {
        return findNextAvailableSpot(col) != -1;
    }

    // Check board still has at least one legal move
    @Override
    public boolean existLegalMoves() {
        for (int i = 0; i < NUM_OF_COLUMNS; i++) {
            if (isLegalMove(i)) {
                return true;
            }
        }
        return false;
    }

    // Add a piece to the board
    @Override
    public void updateMove(int col, Piece move) {
        int row = findNextAvailableSpot(col);
        if (row != -1) {
            pieces[col][row] = move; // place the piece
        }
    }

    // Check for winner
    @Override
    public Winner findWinner() {

        // Check horizontal
        for (int i = 0; i < NUM_OF_ROWS; i++) {
            for (int j = 0; j <= NUM_OF_COLUMNS - 4; j++) {
                Piece p = pieces[j][i];
                if (p != Piece.EMPTY &&
                        p == pieces[j + 1][i] &&
                        p == pieces[j + 2][i] &&
                        p == pieces[j + 3][i]) {

                    // return horizontal winner
                    return new Winner(p, j, i, j + 3, i);
                }
            }
        }

        // Check vertical
        for (int i = 0; i < NUM_OF_COLUMNS; i++) {
            for (int j = 0; j <= NUM_OF_ROWS - 4; j++) {
                Piece p = pieces[i][j];
                if (p != Piece.EMPTY &&
                        p == pieces[i][j + 1] &&
                        p == pieces[i][j + 2] &&
                        p == pieces[i][j + 3]) {

                    // return vertical winner
                    return new Winner(p, i, j, i, j + 3);
                }
            }
        }

        // No winner found
        return new Winner(Piece.EMPTY);
    }

}
