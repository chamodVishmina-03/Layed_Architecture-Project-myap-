package lk.ijse.dep.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class AiPlayer extends Player {

    private static final Random RANDOM = new Random(); // Random generator for AI moves

    public AiPlayer(Board board) {
        super(board); // Call parent constructor to initialize the board
    }

    @Override
    public void movePiece(int col) {

        if (!board.existLegalMoves()) return; // Exit if no legal moves available

        int best = findBestMove(); // Determine the best move for AI

        board.updateMove(best, Piece.GREEN); // Apply AI move to board
        board.getBoardUI().update(best, false); // Update UI for AI move

        Winner w = board.findWinner(); // Check if there is a winner
        if (w.getWinningPiece() != Piece.EMPTY) {
            board.getBoardUI().notifyWinner(w); // Notify UI if AI or player won
        } else if (!board.existLegalMoves()) {
            board.getBoardUI().notifyWinner(new Winner(Piece.EMPTY)); // Notify UI if it's a draw
        }
    }



    private int findBestMove() {
        List<Integer> legal = getLegalMoves(); // Get all legal columns for move

        //  AI tries to win
        for (int col : legal) {
            if (isWinningMove(col, Piece.GREEN)) return col; // Return winning move if possible
        }

        //  Block opponent
        for (int col : legal) {
            if (isWinningMove(col, Piece.BLUE)) return col; // Block opponent if they can win
        }

        //  Otherwise random
        return legal.get(RANDOM.nextInt(legal.size())); // Pick a random legal move
    }

    private List<Integer> getLegalMoves() {
        List<Integer> list = new ArrayList<>();
        for (int c = 0; c < BoardImpl.NUM_OF_COLUMNS; c++) {
            if (board.isLegalMove(c)) list.add(c); // Add legal columns to list
        }
        return list;
    }

    private boolean isWinningMove(int col, Piece piece) {
        SimBoard sim = new SimBoard((BoardImpl) board); // Simulate a board for testing
        if (!sim.isLegalMove(col)) return false; // Cannot win if move is illegal

        sim.updateMove(col, piece); // Apply move on simulated board
        return sim.findWinner() == piece; // Check if move results in a win
    }

    // ----------------  INNER CLASS ----------------------------

    private static class SimBoard {
        private final Piece[][] grid; // Simulated board grid

        SimBoard(BoardImpl real) {
            grid = new Piece[BoardImpl.NUM_OF_COLUMNS][BoardImpl.NUM_OF_ROWS]; // Initialize empty grid
            Piece[][] orig = real.getPieces(); // Get original board pieces

            for (int c = 0; c < BoardImpl.NUM_OF_COLUMNS; c++) {
                System.arraycopy(orig[c], 0, grid[c], 0, BoardImpl.NUM_OF_ROWS); // Copy original board
            }
        }

        boolean isLegalMove(int col) {
            return findEmptyRow(col) != -1; // Return true if column has space
        }

        void updateMove(int col, Piece piece) {
            int row = findEmptyRow(col); // Find first empty row in column
            if (row != -1) grid[col][row] = piece; // Place piece in empty row
        }

        int findEmptyRow(int col) {
            for (int r = 0; r < BoardImpl.NUM_OF_ROWS; r++) {
                if (grid[col][r] == Piece.EMPTY) return r; // Return first empty row
            }
            return -1; // Return -1 if column full
        }

        Piece findWinner() {
            // check horizontal
            for (int r = 0; r < BoardImpl.NUM_OF_ROWS; r++) {
                for (int c = 0; c <= BoardImpl.NUM_OF_COLUMNS - 4; c++) {
                    Piece p = grid[c][r];
                    if (p != Piece.EMPTY &&
                            p == grid[c + 1][r] &&
                            p == grid[c + 2][r] &&
                            p == grid[c + 3][r])
                        return p; // Return winner if 4 horizontal in a row
                }
            }

            // check vertical
            for (int c = 0; c < BoardImpl.NUM_OF_COLUMNS; c++) {
                for (int r = 0; r <= BoardImpl.NUM_OF_ROWS - 4; r++) {
                    Piece p = grid[c][r];
                    if (p != Piece.EMPTY &&
                            p == grid[c][r + 1] &&
                            p == grid[c][r + 2] &&
                            p == grid[c][r + 3])
                        return p; // Return winner if 4 vertical in a column
                }
            }

            return Piece.EMPTY; // Return empty if no winner
        }
    }
}
