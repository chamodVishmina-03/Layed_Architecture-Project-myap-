package lk.ijse.dep.service;

public interface Board {
    int NUM_OF_ROWS = 5;  // number of columns and rows in game board
    int NUM_OF_COLUMNS =6;

    BoardUI getBoardUI();     // update the UI board
    int findNextAvailableSpot(int col);   // find next empty row in a column
    boolean isLegalMove(int col);    // Check if the selected column can accept a piece
    boolean existLegalMoves();   //check there is a least one valid move left
    void updateMove(int col, Piece move);   //Add a piece to colum

    Winner findWinner();  //check their is a winner in the board


}
