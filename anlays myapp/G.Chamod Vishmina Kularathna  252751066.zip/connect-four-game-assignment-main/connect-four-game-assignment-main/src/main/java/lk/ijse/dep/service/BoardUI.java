package lk.ijse.dep.service;

public interface BoardUI {
    void update(int col,boolean isHuman);  // update board if player drop piece
    void notifyWinner(Winner winner);   // Show who won the game

}
