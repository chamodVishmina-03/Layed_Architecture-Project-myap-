package lk.ijse.dep.service;


public abstract class Player {
    protected Board board; // can access for child class using protected keyword
    public Player(Board board) {
        this.board = board;   // store objects
    }
    public abstract void movePiece(int col); // players must provide their own move logic
}
